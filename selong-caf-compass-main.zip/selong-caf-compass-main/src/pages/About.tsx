import { Coffee, Target, Users, Lightbulb, Heart } from "lucide-react";
import { Link } from "react-router-dom";
import { Layout } from "@/components/layout/Layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const features = [
  {
    icon: Target,
    title: "Smart Recommendations",
    description:
      "Our system uses proven decision-making methods to match you with cafés that truly fit your preferences.",
  },
  {
    icon: Users,
    title: "Made for Gen Z",
    description:
      "Designed with students and young adults in mind — modern, intuitive, and focused on what matters to you.",
  },
  {
    icon: Lightbulb,
    title: "Easy to Use",
    description:
      "Simply rank your priorities, and we'll do the math. No complex forms or confusing options.",
  },
  {
    icon: Heart,
    title: "Local Love",
    description:
      "We celebrate Selong's café culture and help you discover hidden gems in your city.",
  },
];

export default function About() {
  return (
    <Layout>
      <div className="bg-gradient-to-b from-secondary/50 to-background">
        <div className="container mx-auto px-4 py-12">
          <div className="mx-auto max-w-2xl text-center">
            <div className="mb-4 inline-flex animate-fade-in items-center justify-center gap-2 rounded-full bg-primary/10 px-4 py-2">
              <Coffee className="h-4 w-4 text-primary" />
              <span className="text-sm font-medium text-primary">About Us</span>
            </div>
            <h1
              className="mb-4 animate-fade-in font-display text-3xl font-bold text-foreground md:text-4xl"
              style={{ animationDelay: "100ms" }}
            >
              Finding Your Perfect Café, Made Simple
            </h1>
            <p
              className="animate-fade-in text-lg leading-relaxed text-muted-foreground"
              style={{ animationDelay: "200ms" }}
            >
              Café Finder Selong is a decision support system designed to help you
              discover the ideal coffee spot based on what truly matters to you.
            </p>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        {/* Mission Section */}
        <div className="mx-auto mb-16 max-w-3xl">
          <Card
            className="animate-fade-in border-border/50"
            style={{ animationDelay: "300ms" }}
          >
            <CardContent className="p-8">
              <h2 className="mb-4 font-display text-2xl font-semibold text-foreground">
                Our Mission
              </h2>
              <p className="mb-4 leading-relaxed text-muted-foreground">
                We believe that finding the right café shouldn't be a matter of
                trial and error. Whether you're looking for a quiet study spot, a
                trendy hangout with friends, or the best coffee in town, your
                preferences matter.
              </p>
              <p className="leading-relaxed text-muted-foreground">
                That's why we built this platform — to transform the way you
                discover cafés in Selong City. By understanding your priorities
                and using smart algorithms, we connect you with coffee spots that
                match your unique style.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Features */}
        <div className="mb-16">
          <h2 className="mb-8 text-center font-display text-2xl font-semibold text-foreground">
            Why Use Café Finder?
          </h2>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {features.map((feature, index) => (
              <Card
                key={feature.title}
                className="animate-fade-in-up border-border/50"
                style={{ animationDelay: `${(index + 4) * 100}ms` }}
              >
                <CardContent className="p-6 text-center">
                  <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
                    <feature.icon className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="mb-2 font-display text-lg font-semibold text-foreground">
                    {feature.title}
                  </h3>
                  <p className="text-sm leading-relaxed text-muted-foreground">
                    {feature.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* How It Works Section */}
        <div className="mx-auto mb-16 max-w-3xl">
          <Card
            className="animate-fade-in border-border/50"
            style={{ animationDelay: "600ms" }}
          >
            <CardContent className="p-8">
              <h2 className="mb-6 font-display text-2xl font-semibold text-foreground">
                The Science Behind It
              </h2>

              <div className="space-y-6">
                <div>
                  <h3 className="mb-2 font-semibold text-foreground">
                    ROC Method (Rank Order Centroid)
                  </h3>
                  <p className="text-muted-foreground">
                    When you rank your preferences, we use the ROC method to
                    automatically calculate how much weight each criterion should
                    have. It's a proven approach in decision science that ensures
                    your top priority has the biggest impact on results.
                  </p>
                </div>

                <div>
                  <h3 className="mb-2 font-semibold text-foreground">
                    SMART Method
                  </h3>
                  <p className="text-muted-foreground">
                    SMART (Simple Multi-Attribute Rating Technique) helps us
                    evaluate each café against your criteria. We normalize scores
                    and apply your personalized weights to find the best matches.
                    The result? Recommendations that actually make sense for you.
                  </p>
                </div>

                <div className="rounded-xl bg-secondary/50 p-4">
                  <p className="text-sm text-muted-foreground">
                    <strong className="text-foreground">In simple terms:</strong>{" "}
                    You tell us what matters most, and our system does the math to
                    find cafés that check all your boxes — no guesswork needed!
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* CTA */}
        <div className="animate-fade-in text-center" style={{ animationDelay: "700ms" }}>
          <h2 className="mb-4 font-display text-2xl font-semibold text-foreground">
            Ready to Find Your Spot?
          </h2>
          <p className="mb-8 text-muted-foreground">
            Start exploring Selong's finest cafés today
          </p>
          <div className="flex flex-col items-center justify-center gap-4 sm:flex-row">
            <Button asChild size="lg" className="btn-bounce rounded-xl px-8">
              <Link to="/cafes">Browse Cafés</Link>
            </Button>
            <Button
              asChild
              variant="outline"
              size="lg"
              className="btn-bounce rounded-xl px-8"
            >
              <Link to="/criteria">Set Preferences</Link>
            </Button>
          </div>
        </div>
      </div>
    </Layout>
  );
}
