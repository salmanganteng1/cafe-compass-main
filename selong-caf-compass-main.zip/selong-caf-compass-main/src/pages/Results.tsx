import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Trophy, Medal, Award, Star, ArrowRight, RotateCcw } from "lucide-react";
import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { cafes, Cafe, CriteriaWeight, defaultCriteria } from "@/data/cafes";

interface RankedCafe extends Cafe {
  score: number;
  rank: number;
}

export default function Results() {
  const [rankedCafes, setRankedCafes] = useState<RankedCafe[]>([]);
  const [criteria, setCriteria] = useState<CriteriaWeight[]>(defaultCriteria);

  useEffect(() => {
    // Get user criteria from session storage
    const storedCriteria = sessionStorage.getItem("userCriteria");
    const userCriteria: CriteriaWeight[] = storedCriteria
      ? JSON.parse(storedCriteria)
      : defaultCriteria;
    setCriteria(userCriteria);

    // Calculate scores using SMART method
    const scored = cafes.map((cafe) => {
      // Normalize values to 0-1 scale (assuming max is 5)
      const normalizedMenu = cafe.menuVariety / 5;
      const normalizedPrice = (4 - cafe.priceRange) / 3; // Inverse: lower price = better
      const normalizedAtmosphere = cafe.atmosphere / 5;
      const normalizedService = cafe.service / 5;
      const normalizedFacilities = cafe.facilities / 5;

      // Get weights from criteria (matched by id)
      const weights = {
        menu: userCriteria.find((c) => c.id === "menu")?.weight || 0.2,
        price: userCriteria.find((c) => c.id === "price")?.weight || 0.2,
        atmosphere: userCriteria.find((c) => c.id === "atmosphere")?.weight || 0.2,
        service: userCriteria.find((c) => c.id === "service")?.weight || 0.2,
        facilities: userCriteria.find((c) => c.id === "facilities")?.weight || 0.2,
      };

      // Calculate weighted score
      const score =
        normalizedMenu * weights.menu +
        normalizedPrice * weights.price +
        normalizedAtmosphere * weights.atmosphere +
        normalizedService * weights.service +
        normalizedFacilities * weights.facilities;

      return {
        ...cafe,
        score: Math.round(score * 100),
        rank: 0,
      };
    });

    // Sort by score and assign ranks
    const sorted = scored
      .sort((a, b) => b.score - a.score)
      .map((cafe, index) => ({
        ...cafe,
        rank: index + 1,
      }));

    setRankedCafes(sorted);
  }, []);

  const top3 = rankedCafes.slice(0, 3);
  const others = rankedCafes.slice(3);

  const rankIcons = [Trophy, Medal, Award];
  const rankColors = [
    "from-yellow-400 to-amber-500",
    "from-slate-300 to-slate-400",
    "from-amber-600 to-amber-700",
  ];

  return (
    <Layout>
      <div className="bg-gradient-to-b from-secondary/50 to-background">
        <div className="container mx-auto px-4 py-12">
          <div className="mx-auto max-w-2xl text-center">
            <h1 className="mb-3 animate-fade-in font-display text-3xl font-bold text-foreground md:text-4xl">
              Your Perfect Café Matches
            </h1>
            <p
              className="animate-fade-in text-muted-foreground"
              style={{ animationDelay: "100ms" }}
            >
              Based on your preferences, here are the top recommendations
            </p>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Top 3 Spotlight */}
        <div className="mb-12">
          <h2 className="mb-6 text-center font-display text-2xl font-semibold text-foreground">
            Top 3 Picks
          </h2>
          <div className="grid gap-6 md:grid-cols-3">
            {top3.map((cafe, index) => {
              const RankIcon = rankIcons[index];
              return (
                <Card
                  key={cafe.id}
                  className="animate-scale-in group relative overflow-hidden border-border/50 transition-all duration-300 hover:shadow-elevated"
                  style={{ animationDelay: `${index * 150}ms` }}
                >
                  {/* Rank Badge */}
                  <div
                    className={`absolute -right-8 -top-8 h-24 w-24 rounded-full bg-gradient-to-br ${rankColors[index]} opacity-20`}
                  />
                  <div
                    className={`absolute right-3 top-3 flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br ${rankColors[index]}`}
                  >
                    <RankIcon className="h-5 w-5 text-white" />
                  </div>

                  <CardContent className="p-6">
                    <div className="mb-4">
                      <span className="text-sm font-medium text-primary">
                        #{cafe.rank} Recommended
                      </span>
                      <h3 className="mt-1 font-display text-xl font-semibold text-foreground">
                        {cafe.name}
                      </h3>
                      <p className="mt-1 text-sm text-muted-foreground">
                        {cafe.location}
                      </p>
                    </div>

                    <p className="mb-4 text-sm leading-relaxed text-muted-foreground">
                      {cafe.description}
                    </p>

                    <div className="mb-4 flex flex-wrap gap-1.5">
                      {cafe.tags.slice(0, 2).map((tag) => (
                        <Badge
                          key={tag}
                          variant="secondary"
                          className="rounded-full text-xs"
                        >
                          {tag}
                        </Badge>
                      ))}
                    </div>

                    <div className="mb-4">
                      <div className="mb-1 flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">Match Score</span>
                        <span className="font-semibold text-primary">
                          {cafe.score}%
                        </span>
                      </div>
                      <Progress value={cafe.score} className="h-2" />
                    </div>

                    <Button
                      asChild
                      variant={index === 0 ? "default" : "outline"}
                      className="btn-bounce w-full rounded-xl"
                    >
                      <Link to={`/cafes/${cafe.id}`}>View Details</Link>
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Full Rankings */}
        <div className="mx-auto max-w-3xl">
          <h2 className="mb-6 font-display text-2xl font-semibold text-foreground">
            Full Rankings
          </h2>
          <div className="space-y-3">
            {rankedCafes.map((cafe, index) => (
              <Card
                key={cafe.id}
                className="animate-fade-in-up border-border/50 transition-all duration-200 hover:shadow-card"
                style={{ animationDelay: `${(index + 3) * 50}ms` }}
              >
                <CardContent className="flex items-center gap-4 p-4">
                  {/* Rank */}
                  <div
                    className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl font-display text-lg font-bold ${
                      cafe.rank <= 3
                        ? "bg-primary text-primary-foreground"
                        : "bg-secondary text-foreground"
                    }`}
                  >
                    {cafe.rank}
                  </div>

                  {/* Info */}
                  <div className="flex-1">
                    <h3 className="font-semibold text-foreground">{cafe.name}</h3>
                    <p className="text-sm text-muted-foreground">
                      {cafe.location}
                    </p>
                  </div>

                  {/* Score */}
                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <div className="text-lg font-semibold text-primary">
                        {cafe.score}%
                      </div>
                      <div className="flex items-center gap-0.5">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <Star
                            key={i}
                            className={`h-3 w-3 ${
                              i < Math.round(cafe.score / 20)
                                ? "fill-primary text-primary"
                                : "text-muted-foreground/30"
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                    <Button
                      asChild
                      variant="ghost"
                      size="icon"
                      className="shrink-0"
                    >
                      <Link to={`/cafes/${cafe.id}`}>
                        <ArrowRight className="h-4 w-4" />
                      </Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Actions */}
        <div className="mt-12 flex flex-col items-center justify-center gap-4 sm:flex-row">
          <Button asChild variant="outline" className="btn-bounce gap-2 rounded-xl">
            <Link to="/criteria">
              <RotateCcw className="h-4 w-4" />
              Adjust Preferences
            </Link>
          </Button>
          <Button asChild className="btn-bounce rounded-xl">
            <Link to="/cafes">Explore All Cafés</Link>
          </Button>
        </div>
      </div>
    </Layout>
  );
}
