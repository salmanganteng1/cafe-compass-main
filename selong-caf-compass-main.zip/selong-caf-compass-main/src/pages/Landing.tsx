import { Link } from "react-router-dom";
import { Coffee, ArrowRight, Sparkles, Search, BarChart3 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Layout } from "@/components/layout/Layout";

const steps = [
  {
    icon: Search,
    title: "Explore Cafés",
    description: "Browse through 15 carefully curated cafés in Selong City",
  },
  {
    icon: Sparkles,
    title: "Set Preferences",
    description: "Rank what matters most: menu, price, vibe, service, or facilities",
  },
  {
    icon: BarChart3,
    title: "Get Recommendations",
    description: "Our smart system finds your perfect café match",
  },
];

export default function Landing() {
  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-secondary/50 to-background">
        {/* Decorative Elements */}
        <div className="absolute -left-20 top-20 h-72 w-72 rounded-full bg-primary/5 blur-3xl" />
        <div className="absolute -right-20 bottom-20 h-96 w-96 rounded-full bg-accent/5 blur-3xl" />

        <div className="container relative mx-auto px-4 py-20 md:py-32">
          <div className="mx-auto max-w-3xl text-center">
            {/* Badge */}
            <div className="mb-6 inline-flex animate-fade-in items-center gap-2 rounded-full bg-primary/10 px-4 py-2 text-sm text-primary">
              <Coffee className="h-4 w-4" />
              <span>Discover Selong's Best Coffee Spots</span>
            </div>

            {/* Headline */}
            <h1
              className="mb-6 animate-fade-in font-display text-4xl font-bold leading-tight text-foreground md:text-5xl lg:text-6xl"
              style={{ animationDelay: "100ms" }}
            >
              Find Your Perfect{" "}
              <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                Café
              </span>{" "}
              in Selong
            </h1>

            {/* Description */}
            <p
              className="mb-8 animate-fade-in text-lg leading-relaxed text-muted-foreground md:text-xl"
              style={{ animationDelay: "200ms" }}
            >
              Whether you're looking for a cozy study spot, a trendy hangout, or the
              best sunset views — we'll help you discover the ideal café based on
              your preferences.
            </p>

            {/* CTA Button */}
            <div
              className="animate-fade-in"
              style={{ animationDelay: "300ms" }}
            >
              <Button
                asChild
                size="lg"
                className="btn-bounce group rounded-xl px-8 py-6 text-lg"
              >
                <Link to="/cafes">
                  Start Exploring
                  <ArrowRight className="ml-2 h-5 w-5 transition-transform group-hover:translate-x-1" />
                </Link>
              </Button>
            </div>
          </div>

          {/* Floating Coffee Icons */}
          <div className="absolute left-10 top-1/3 animate-float opacity-20 md:opacity-40">
            <Coffee className="h-12 w-12 text-primary" />
          </div>
          <div
            className="absolute right-10 top-1/2 animate-float opacity-20 md:opacity-40"
            style={{ animationDelay: "1s" }}
          >
            <Coffee className="h-8 w-8 text-accent" />
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="bg-background py-20">
        <div className="container mx-auto px-4">
          <div className="mb-12 text-center">
            <h2 className="mb-3 font-display text-3xl font-bold text-foreground md:text-4xl">
              How It Works
            </h2>
            <p className="text-muted-foreground">
              Three simple steps to find your ideal café
            </p>
          </div>

          <div className="mx-auto grid max-w-4xl gap-8 md:grid-cols-3">
            {steps.map((step, index) => (
              <div
                key={step.title}
                className="animate-fade-in-up group text-center"
                style={{ animationDelay: `${index * 150}ms` }}
              >
                <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10 transition-all duration-300 group-hover:bg-primary group-hover:shadow-lg">
                  <step.icon className="h-7 w-7 text-primary transition-colors group-hover:text-primary-foreground" />
                </div>
                <div className="mb-2 text-sm font-medium text-primary">
                  Step {index + 1}
                </div>
                <h3 className="mb-2 font-display text-xl font-semibold text-foreground">
                  {step.title}
                </h3>
                <p className="text-sm leading-relaxed text-muted-foreground">
                  {step.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="bg-secondary/30 py-20">
        <div className="container mx-auto px-4">
          <div className="mx-auto max-w-4xl">
            <div className="grid items-center gap-12 md:grid-cols-2">
              <div className="animate-fade-in">
                <h2 className="mb-4 font-display text-3xl font-bold text-foreground">
                  Smart Recommendations, Just for You
                </h2>
                <p className="mb-6 leading-relaxed text-muted-foreground">
                  Our decision support system uses proven methods (SMART & ROC) to
                  analyze your preferences and match you with cafés that truly fit
                  your style. No more guessing — just great coffee experiences.
                </p>
                <ul className="space-y-3">
                  {[
                    "Personalized café rankings",
                    "Compare based on what matters to you",
                    "Discover hidden gems in Selong",
                    "Made for students & young adults",
                  ].map((item) => (
                    <li key={item} className="flex items-center gap-2 text-foreground">
                      <div className="h-1.5 w-1.5 rounded-full bg-primary" />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="grid grid-cols-2 gap-4 animate-fade-in" style={{ animationDelay: "200ms" }}>
                {["☕", "🍰", "📚", "🌅"].map((emoji, index) => (
                  <div
                    key={index}
                    className="flex aspect-square items-center justify-center rounded-2xl bg-card text-4xl shadow-card transition-transform hover:scale-105"
                  >
                    {emoji}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-background py-20">
        <div className="container mx-auto px-4 text-center">
          <div className="mx-auto max-w-2xl animate-fade-in">
            <h2 className="mb-4 font-display text-3xl font-bold text-foreground">
              Ready to Find Your Spot?
            </h2>
            <p className="mb-8 text-muted-foreground">
              Join hundreds of café lovers in Selong who found their perfect hangout
            </p>
            <div className="flex flex-col items-center justify-center gap-4 sm:flex-row">
              <Button asChild size="lg" className="btn-bounce rounded-xl px-8">
                <Link to="/cafes">Browse All Cafés</Link>
              </Button>
              <Button
                asChild
                variant="outline"
                size="lg"
                className="btn-bounce rounded-xl px-8"
              >
                <Link to="/criteria">Set My Preferences</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}
