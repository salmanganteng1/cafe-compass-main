import { useParams, Link, useNavigate } from "react-router-dom";
import {
  ArrowLeft,
  MapPin,
  DollarSign,
  Star,
  UtensilsCrossed,
  Sparkles,
  Heart,
  Settings,
} from "lucide-react";
import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { FacilityIcon } from "@/components/cafe/FacilityIcon";
import { getCafeById } from "@/data/cafes";

const ratingLabels = ["Menu Variety", "Atmosphere", "Service", "Facilities"];

export default function CafeDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const cafe = getCafeById(id || "");

  if (!cafe) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-20 text-center">
          <h1 className="mb-4 font-display text-2xl font-bold">Café Not Found</h1>
          <p className="mb-8 text-muted-foreground">
            The café you're looking for doesn't exist.
          </p>
          <Button asChild>
            <Link to="/cafes">Back to Cafés</Link>
          </Button>
        </div>
      </Layout>
    );
  }

  const ratings = [
    { label: "Menu Variety", value: cafe.menuVariety, icon: UtensilsCrossed },
    { label: "Atmosphere", value: cafe.atmosphere, icon: Sparkles },
    { label: "Service Quality", value: cafe.service, icon: Heart },
    { label: "Facilities", value: cafe.facilities, icon: Settings },
  ];

  return (
    <Layout>
      {/* Header */}
      <div className="bg-gradient-to-b from-secondary/50 to-background">
        <div className="container mx-auto px-4 py-8">
          <Button
            variant="ghost"
            onClick={() => navigate(-1)}
            className="mb-6 gap-2"
          >
            <ArrowLeft className="h-4 w-4" />
            Back
          </Button>

          <div className="animate-fade-in">
            <div className="mb-4 flex flex-wrap items-center gap-3">
              {cafe.tags.map((tag) => (
                <Badge
                  key={tag}
                  variant="secondary"
                  className="rounded-full"
                >
                  {tag}
                </Badge>
              ))}
            </div>

            <h1 className="mb-2 font-display text-3xl font-bold text-foreground md:text-4xl">
              {cafe.name}
            </h1>

            <div className="flex flex-wrap items-center gap-4 text-muted-foreground">
              <div className="flex items-center gap-1">
                <MapPin className="h-4 w-4" />
                <span>{cafe.location}</span>
              </div>
              <div className="flex items-center gap-0.5">
                {Array.from({ length: cafe.priceRange }).map((_, i) => (
                  <DollarSign key={i} className="h-4 w-4 text-primary" />
                ))}
                {Array.from({ length: 3 - cafe.priceRange }).map((_, i) => (
                  <DollarSign key={i} className="h-4 w-4 text-muted-foreground/30" />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 py-8">
        <div className="grid gap-8 lg:grid-cols-3">
          {/* Main Content */}
          <div className="space-y-8 lg:col-span-2">
            {/* Description */}
            <Card className="animate-fade-in border-border/50">
              <CardContent className="p-6">
                <h2 className="mb-3 font-display text-xl font-semibold">About</h2>
                <p className="leading-relaxed text-muted-foreground">
                  {cafe.description}
                </p>
              </CardContent>
            </Card>

            {/* Atmosphere */}
            <Card
              className="animate-fade-in border-border/50"
              style={{ animationDelay: "100ms" }}
            >
              <CardContent className="p-6">
                <h2 className="mb-3 font-display text-xl font-semibold">
                  Atmosphere & Vibe
                </h2>
                <p className="leading-relaxed text-muted-foreground">
                  {cafe.atmosphereDescription}
                </p>
              </CardContent>
            </Card>

            {/* Service */}
            <Card
              className="animate-fade-in border-border/50"
              style={{ animationDelay: "150ms" }}
            >
              <CardContent className="p-6">
                <h2 className="mb-3 font-display text-xl font-semibold">
                  Service Experience
                </h2>
                <p className="leading-relaxed text-muted-foreground">
                  {cafe.serviceDescription}
                </p>
              </CardContent>
            </Card>

            {/* Menu Highlights */}
            <Card
              className="animate-fade-in border-border/50"
              style={{ animationDelay: "200ms" }}
            >
              <CardContent className="p-6">
                <h2 className="mb-4 font-display text-xl font-semibold">
                  Menu Highlights
                </h2>
                <div className="flex flex-wrap gap-2">
                  {cafe.menuHighlights.map((item) => (
                    <Badge
                      key={item}
                      variant="outline"
                      className="rounded-full border-primary/20 bg-primary/5 px-3 py-1.5"
                    >
                      {item}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Ratings */}
            <Card
              className="animate-fade-in border-border/50"
              style={{ animationDelay: "100ms" }}
            >
              <CardContent className="p-6">
                <h2 className="mb-4 font-display text-xl font-semibold">
                  Ratings
                </h2>
                <div className="space-y-4">
                  {ratings.map((rating) => (
                    <div key={rating.label}>
                      <div className="mb-2 flex items-center justify-between text-sm">
                        <div className="flex items-center gap-2">
                          <rating.icon className="h-4 w-4 text-primary" />
                          <span className="text-foreground">{rating.label}</span>
                        </div>
                        <span className="font-medium text-foreground">
                          {rating.value}/5
                        </span>
                      </div>
                      <Progress value={rating.value * 20} className="h-2" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Facilities */}
            <Card
              className="animate-fade-in border-border/50"
              style={{ animationDelay: "150ms" }}
            >
              <CardContent className="p-6">
                <h2 className="mb-4 font-display text-xl font-semibold">
                  Facilities
                </h2>
                <div className="grid grid-cols-3 gap-4">
                  {cafe.facilityList.map((facilityKey) => (
                    <FacilityIcon
                      key={facilityKey}
                      facilityKey={facilityKey}
                      showLabel
                      size="lg"
                    />
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Actions */}
            <Card
              className="animate-fade-in border-border/50"
              style={{ animationDelay: "200ms" }}
            >
              <CardContent className="p-6">
                <Button asChild className="btn-bounce w-full rounded-xl">
                  <Link to="/criteria">Find Similar Cafés</Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
}
