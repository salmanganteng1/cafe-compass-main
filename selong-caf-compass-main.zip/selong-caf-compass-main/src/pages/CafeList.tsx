import { useState } from "react";
import { Search, SlidersHorizontal } from "lucide-react";
import { Layout } from "@/components/layout/Layout";
import { CafeCard } from "@/components/cafe/CafeCard";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cafes } from "@/data/cafes";

const allTags = Array.from(new Set(cafes.flatMap((cafe) => cafe.tags)));

export default function CafeList() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedTags, setSelectedTags] = useState<string[]>([]);

  const filteredCafes = cafes.filter((cafe) => {
    const matchesSearch =
      cafe.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      cafe.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      cafe.location.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesTags =
      selectedTags.length === 0 ||
      selectedTags.some((tag) => cafe.tags.includes(tag));

    return matchesSearch && matchesTags;
  });

  const toggleTag = (tag: string) => {
    setSelectedTags((prev) =>
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
    );
  };

  return (
    <Layout>
      <div className="bg-gradient-to-b from-secondary/50 to-background">
        <div className="container mx-auto px-4 py-12">
          {/* Header */}
          <div className="mb-8 text-center">
            <h1 className="mb-3 animate-fade-in font-display text-3xl font-bold text-foreground md:text-4xl">
              Explore Selong's Finest Cafés
            </h1>
            <p className="animate-fade-in text-muted-foreground" style={{ animationDelay: "100ms" }}>
              Discover {cafes.length} unique coffee spots waiting for you
            </p>
          </div>

          {/* Search & Filter */}
          <div className="mb-8 animate-fade-in" style={{ animationDelay: "200ms" }}>
            <div className="mx-auto max-w-xl">
              <div className="relative">
                <Search className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  type="text"
                  placeholder="Search by name, location, or description..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="rounded-xl border-border/50 bg-card py-6 pl-11 pr-4"
                />
              </div>
            </div>
          </div>

          {/* Tags Filter */}
          <div
            className="mb-8 animate-fade-in"
            style={{ animationDelay: "300ms" }}
          >
            <div className="flex flex-wrap items-center justify-center gap-2">
              <span className="mr-2 text-sm text-muted-foreground">Filter:</span>
              {allTags.slice(0, 10).map((tag) => (
                <Badge
                  key={tag}
                  variant={selectedTags.includes(tag) ? "default" : "secondary"}
                  className="cursor-pointer rounded-full px-3 py-1 transition-all hover:scale-105"
                  onClick={() => toggleTag(tag)}
                >
                  {tag}
                </Badge>
              ))}
              {selectedTags.length > 0 && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setSelectedTags([])}
                  className="text-sm text-muted-foreground"
                >
                  Clear all
                </Button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Café Grid */}
      <div className="container mx-auto px-4 py-8">
        {filteredCafes.length > 0 ? (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {filteredCafes.map((cafe, index) => (
              <div
                key={cafe.id}
                className="animate-fade-in-up"
                style={{ animationDelay: `${index * 50}ms` }}
              >
                <CafeCard cafe={cafe} index={index} />
              </div>
            ))}
          </div>
        ) : (
          <div className="py-20 text-center">
            <p className="text-lg text-muted-foreground">
              No cafés found matching your criteria
            </p>
            <Button
              variant="outline"
              className="mt-4"
              onClick={() => {
                setSearchQuery("");
                setSelectedTags([]);
              }}
            >
              Clear filters
            </Button>
          </div>
        )}
      </div>
    </Layout>
  );
}
