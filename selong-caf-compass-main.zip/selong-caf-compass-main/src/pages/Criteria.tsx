import { useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import {
  UtensilsCrossed,
  Wallet,
  Sparkles,
  Heart,
  Settings,
  GripVertical,
  ArrowRight,
  Info,
} from "lucide-react";
import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { defaultCriteria, CriteriaWeight } from "@/data/cafes";

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  UtensilsCrossed,
  Wallet,
  Sparkles,
  Heart,
  Settings,
};

// ROC weights based on ranking position
const rocWeights = [0.457, 0.257, 0.157, 0.087, 0.043];

export default function Criteria() {
  const navigate = useNavigate();
  const [rankedCriteria, setRankedCriteria] = useState<CriteriaWeight[]>(
    defaultCriteria
  );
  const [draggedIndex, setDraggedIndex] = useState<number | null>(null);

  const handleDragStart = (index: number) => {
    setDraggedIndex(index);
  };

  const handleDragOver = (e: React.DragEvent, index: number) => {
    e.preventDefault();
    if (draggedIndex === null || draggedIndex === index) return;

    const newCriteria = [...rankedCriteria];
    const draggedItem = newCriteria[draggedIndex];
    newCriteria.splice(draggedIndex, 1);
    newCriteria.splice(index, 0, draggedItem);

    // Recalculate weights based on new positions
    const updatedCriteria = newCriteria.map((criterion, idx) => ({
      ...criterion,
      weight: rocWeights[idx],
    }));

    setRankedCriteria(updatedCriteria);
    setDraggedIndex(index);
  };

  const handleDragEnd = () => {
    setDraggedIndex(null);
  };

  const moveItem = (fromIndex: number, toIndex: number) => {
    if (toIndex < 0 || toIndex >= rankedCriteria.length) return;

    const newCriteria = [...rankedCriteria];
    const [movedItem] = newCriteria.splice(fromIndex, 1);
    newCriteria.splice(toIndex, 0, movedItem);

    const updatedCriteria = newCriteria.map((criterion, idx) => ({
      ...criterion,
      weight: rocWeights[idx],
    }));

    setRankedCriteria(updatedCriteria);
  };

  const handleGetRecommendations = () => {
    // Store criteria in sessionStorage for results page
    sessionStorage.setItem("userCriteria", JSON.stringify(rankedCriteria));
    navigate("/results");
  };

  return (
    <Layout>
      <div className="bg-gradient-to-b from-secondary/50 to-background">
        <div className="container mx-auto px-4 py-12">
          <div className="mx-auto max-w-2xl text-center">
            <h1 className="mb-3 animate-fade-in font-display text-3xl font-bold text-foreground md:text-4xl">
              Set Your Preferences
            </h1>
            <p
              className="animate-fade-in text-muted-foreground"
              style={{ animationDelay: "100ms" }}
            >
              Drag to rank what matters most to you. The top criteria will have
              more influence on your café recommendations.
            </p>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="mx-auto max-w-2xl">
          {/* Info Card */}
          <Card
            className="mb-8 animate-fade-in border-primary/20 bg-primary/5"
            style={{ animationDelay: "200ms" }}
          >
            <CardContent className="flex items-start gap-3 p-4">
              <Info className="mt-0.5 h-5 w-5 shrink-0 text-primary" />
              <div className="text-sm text-foreground">
                <strong>How it works:</strong> We use the ROC (Rank Order
                Centroid) method to calculate weights. The first item gets the
                highest importance, and each subsequent item gets progressively
                less weight.
              </div>
            </CardContent>
          </Card>

          {/* Draggable Criteria List */}
          <div className="mb-8 space-y-3">
            {rankedCriteria.map((criterion, index) => {
              const Icon = iconMap[criterion.icon];
              return (
                <Card
                  key={criterion.id}
                  draggable
                  onDragStart={() => handleDragStart(index)}
                  onDragOver={(e) => handleDragOver(e, index)}
                  onDragEnd={handleDragEnd}
                  className={`animate-fade-in-up cursor-grab border-border/50 transition-all duration-200 active:cursor-grabbing ${
                    draggedIndex === index
                      ? "scale-[1.02] shadow-elevated"
                      : "hover:shadow-card"
                  }`}
                  style={{ animationDelay: `${(index + 3) * 100}ms` }}
                >
                  <CardContent className="flex items-center gap-4 p-4">
                    {/* Rank Number */}
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary font-display text-lg font-bold text-primary-foreground">
                      {index + 1}
                    </div>

                    {/* Drag Handle */}
                    <GripVertical className="h-5 w-5 shrink-0 text-muted-foreground" />

                    {/* Icon */}
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-secondary">
                      {Icon && <Icon className="h-5 w-5 text-foreground" />}
                    </div>

                    {/* Content */}
                    <div className="flex-1">
                      <h3 className="font-semibold text-foreground">
                        {criterion.name}
                      </h3>
                      <p className="text-sm text-muted-foreground">
                        {criterion.description}
                      </p>
                    </div>

                    {/* Weight Display */}
                    <div className="w-24 text-right">
                      <div className="text-lg font-semibold text-primary">
                        {Math.round(criterion.weight * 100)}%
                      </div>
                      <Progress
                        value={criterion.weight * 100}
                        className="mt-1 h-1.5"
                      />
                    </div>

                    {/* Move Buttons (Mobile Friendly) */}
                    <div className="flex flex-col gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6"
                        onClick={() => moveItem(index, index - 1)}
                        disabled={index === 0}
                      >
                        <span className="text-xs">↑</span>
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6"
                        onClick={() => moveItem(index, index + 1)}
                        disabled={index === rankedCriteria.length - 1}
                      >
                        <span className="text-xs">↓</span>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Weight Distribution Visualization */}
          <Card
            className="mb-8 animate-fade-in border-border/50"
            style={{ animationDelay: "600ms" }}
          >
            <CardContent className="p-6">
              <h3 className="mb-4 font-display text-lg font-semibold">
                Weight Distribution
              </h3>
              <div className="flex h-8 overflow-hidden rounded-xl">
                {rankedCriteria.map((criterion, index) => {
                  const Icon = iconMap[criterion.icon];
                  const colors = [
                    "bg-primary",
                    "bg-accent",
                    "bg-cafe-caramel",
                    "bg-cafe-terracotta",
                    "bg-muted-foreground",
                  ];
                  return (
                    <div
                      key={criterion.id}
                      className={`flex items-center justify-center transition-all duration-300 ${colors[index]}`}
                      style={{ width: `${criterion.weight * 100}%` }}
                      title={`${criterion.name}: ${Math.round(
                        criterion.weight * 100
                      )}%`}
                    >
                      {Icon && criterion.weight > 0.1 && (
                        <Icon className="h-4 w-4 text-white" />
                      )}
                    </div>
                  );
                })}
              </div>
              <div className="mt-3 flex flex-wrap gap-3">
                {rankedCriteria.map((criterion, index) => {
                  const colors = [
                    "bg-primary",
                    "bg-accent",
                    "bg-cafe-caramel",
                    "bg-cafe-terracotta",
                    "bg-muted-foreground",
                  ];
                  return (
                    <div
                      key={criterion.id}
                      className="flex items-center gap-2 text-sm"
                    >
                      <div className={`h-3 w-3 rounded-full ${colors[index]}`} />
                      <span className="text-muted-foreground">
                        {criterion.name}
                      </span>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {/* Action Button */}
          <div
            className="animate-fade-in text-center"
            style={{ animationDelay: "700ms" }}
          >
            <Button
              size="lg"
              onClick={handleGetRecommendations}
              className="btn-bounce group rounded-xl px-8"
            >
              Get My Recommendations
              <ArrowRight className="ml-2 h-5 w-5 transition-transform group-hover:translate-x-1" />
            </Button>
          </div>
        </div>
      </div>
    </Layout>
  );
}
