import {
  Wifi,
  Snowflake,
  TreePine,
  Home,
  Plug,
  Car,
  Music,
  Heart,
  Wind,
  Users,
} from "lucide-react";
import { facilities } from "@/data/cafes";

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  Wifi,
  Snowflake,
  TreePine,
  Home,
  Plug,
  Car,
  Music,
  Heart,
  Wind,
  Users,
};

interface FacilityIconProps {
  facilityKey: string;
  showLabel?: boolean;
  size?: "sm" | "md" | "lg";
}

export function FacilityIcon({
  facilityKey,
  showLabel = false,
  size = "md",
}: FacilityIconProps) {
  const facility = facilities[facilityKey as keyof typeof facilities];
  if (!facility) return null;

  const Icon = iconMap[facility.icon];
  if (!Icon) return null;

  const sizeClasses = {
    sm: "h-6 w-6",
    md: "h-8 w-8",
    lg: "h-10 w-10",
  };

  const iconSizes = {
    sm: "h-3 w-3",
    md: "h-4 w-4",
    lg: "h-5 w-5",
  };

  return (
    <div className="flex flex-col items-center gap-1">
      <div
        className={`flex items-center justify-center rounded-xl bg-secondary ${sizeClasses[size]}`}
        title={facility.label}
      >
        <Icon className={`text-foreground ${iconSizes[size]}`} />
      </div>
      {showLabel && (
        <span className="text-center text-xs text-muted-foreground">
          {facility.label}
        </span>
      )}
    </div>
  );
}
