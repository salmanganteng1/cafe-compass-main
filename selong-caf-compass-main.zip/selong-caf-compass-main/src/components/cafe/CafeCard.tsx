import { Link } from "react-router-dom";
import { MapPin, Wifi, Snowflake, TreePine, Plug, Car, DollarSign } from "lucide-react";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Cafe, facilities } from "@/data/cafes";
import { cn } from "@/lib/utils";

interface CafeCardProps {
  cafe: Cafe;
  index?: number;
}

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  Wifi,
  Snowflake,
  TreePine,
  Plug,
  Car,
};

export function CafeCard({ cafe, index = 0 }: CafeCardProps) {
  const displayFacilities = cafe.facilityList.slice(0, 4);

  return (
    <Card
      className="card-hover group overflow-hidden border-border/50 bg-card"
      style={{ animationDelay: `${index * 100}ms` }}
    >
      <CardContent className="p-5">
        {/* Header */}
        <div className="mb-3 flex items-start justify-between">
          <div>
            <h3 className="font-display text-lg font-semibold text-foreground transition-colors group-hover:text-primary">
              {cafe.name}
            </h3>
            <div className="mt-1 flex items-center gap-1 text-sm text-muted-foreground">
              <MapPin className="h-3.5 w-3.5" />
              <span>{cafe.location}</span>
            </div>
          </div>
          <div className="flex items-center gap-0.5 rounded-lg bg-secondary px-2 py-1">
            {Array.from({ length: cafe.priceRange }).map((_, i) => (
              <DollarSign
                key={i}
                className="h-3.5 w-3.5 text-primary"
              />
            ))}
            {Array.from({ length: 3 - cafe.priceRange }).map((_, i) => (
              <DollarSign
                key={i}
                className="h-3.5 w-3.5 text-muted-foreground/30"
              />
            ))}
          </div>
        </div>

        {/* Description */}
        <p className="mb-4 text-sm leading-relaxed text-muted-foreground">
          {cafe.description}
        </p>

        {/* Tags */}
        <div className="mb-4 flex flex-wrap gap-1.5">
          {cafe.tags.slice(0, 3).map((tag) => (
            <Badge
              key={tag}
              variant="secondary"
              className="rounded-full text-xs font-normal"
            >
              {tag}
            </Badge>
          ))}
        </div>

        {/* Facilities */}
        <div className="flex items-center gap-2">
          {displayFacilities.map((facilityKey) => {
            const facility = facilities[facilityKey as keyof typeof facilities];
            if (!facility) return null;
            const Icon = iconMap[facility.icon];
            return (
              <div
                key={facilityKey}
                className="flex h-8 w-8 items-center justify-center rounded-lg bg-secondary"
                title={facility.label}
              >
                {Icon && <Icon className="h-4 w-4 text-muted-foreground" />}
              </div>
            );
          })}
          {cafe.facilityList.length > 4 && (
            <span className="text-xs text-muted-foreground">
              +{cafe.facilityList.length - 4} more
            </span>
          )}
        </div>
      </CardContent>

      <CardFooter className="border-t border-border/50 bg-secondary/20 p-4">
        <Button asChild className="btn-bounce w-full rounded-xl">
          <Link to={`/cafes/${cafe.id}`}>View Details</Link>
        </Button>
      </CardFooter>
    </Card>
  );
}
