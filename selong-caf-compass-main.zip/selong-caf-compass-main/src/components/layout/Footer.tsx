import { Coffee, Heart } from "lucide-react";
import { Link } from "react-router-dom";

export function Footer() {
  return (
    <footer className="border-t border-border/50 bg-secondary/30">
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col items-center justify-between gap-6 md:flex-row">
          <Link to="/" className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
              <Coffee className="h-4 w-4 text-primary-foreground" />
            </div>
            <span className="font-display text-lg font-semibold">
              Café Finder Selong
            </span>
          </Link>

          <div className="flex items-center gap-6 text-sm text-muted-foreground">
            <Link to="/cafes" className="transition-colors hover:text-foreground">
              Cafés
            </Link>
            <Link to="/criteria" className="transition-colors hover:text-foreground">
              Preferences
            </Link>
            <Link to="/about" className="transition-colors hover:text-foreground">
              About
            </Link>
          </div>

          <p className="flex items-center gap-1 text-sm text-muted-foreground">
            Made with <Heart className="h-4 w-4 fill-accent text-accent" /> in Selong
          </p>
        </div>

        <div className="mt-6 border-t border-border/50 pt-6 text-center">
          <p className="text-xs text-muted-foreground">
            © {new Date().getFullYear()} Café Finder Selong. A decision support system for café lovers.
          </p>
        </div>
      </div>
    </footer>
  );
}
